Frozen data to be used for project 1 for stable results in T018 (for maintenance).
