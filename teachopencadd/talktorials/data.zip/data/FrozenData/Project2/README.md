Frozen data to be used for project 2 for stable results in T018 (for maintenance).
