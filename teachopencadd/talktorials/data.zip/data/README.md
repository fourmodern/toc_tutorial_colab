# Data

This folder stores input and output data for the Jupyter notebook.

- `xxx.csv`: Describe data.
- `xxx.sdf`: Describe data.
